
public class Main {
    public static void main(String arg[]) {
        
    SplashScreenFrame a=new SplashScreenFrame();
    a.setVisible(true);
    a.setLocationRelativeTo(null);
    }
}
